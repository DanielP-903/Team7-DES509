using System.Collections.Generic;
using UnityEngine;

public enum CharacterName
{
    Shylo, Mimi, Docorty
}
[System.Serializable]
public struct ingredientListValues
{
    public GameObject ingredient;
    public Color colour;
}

public class GameManager : MonoBehaviour
{
   public List<ingredientListValues> m_ingredientList;

   // Game Flags
   public static bool m_hasBrewedATea = false;

   public CharacterName currentCharacter = CharacterName.Shylo;


    public ingredientListValues FindIngredient(string typeToFind)
    {
        ingredientListValues g = new ingredientListValues();

        foreach (ingredientListValues i in m_ingredientList)
        {
            if (i.ingredient.GetComponent<Ingredient>().m_type.ToString() == typeToFind)//m_heldObject.GetComponent<Ingredient>().m_type)
            {
                g = i;
            }
        }

        return g;
    }
}
